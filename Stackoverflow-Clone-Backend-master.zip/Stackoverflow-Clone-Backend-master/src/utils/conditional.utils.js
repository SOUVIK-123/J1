const isArrayEmpty = (array) => array.length === 0;

const isNull = (object) => object === null;

module.exports = conditional = {
  isArrayEmpty,
  isNull,
};
